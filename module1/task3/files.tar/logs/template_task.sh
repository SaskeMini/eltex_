#!/bin/bash

if [[ "$0" == "template_task.sh" ]]; then
	echo "я бригадир, сам не работаю"
	exit 0
fi

FILE_NAME="report_$(echo "$0" | awk -F'/' '{print $NF}').log"
DATE_TIME="$(date) $(date +%T)"
RAND_PID=$((RANDOM % 10000 + 10000))
echo "$DATE_TIME [$RAND_PID] Скрипт запущен" >> "$FILE_NAME"

CUCKOO_PID=$(pgrep -f "cuckoo.sh")
CUCKOO_CMD=$(cat -v "/proc/$CUCKOO_PID/cmdline")

if [[ "$CUCKOO_CMD" =~ --pishitesuda=([^^-]+) ]]; then
    FIFO_NAME=$(echo "${BASH_REMATCH[1]}" | tr -d '^@' | sed 's/\^M//g' | xargs)
else
    echo "Ошибка: Путь к FIFO не найден в procfs"
    exit 1
fi

echo "$0[$RAND_PID]: how much time do I have?" > "$FIFO_NAME"
sleep 1
read -r NUM < "$FIFO_NAME"
sleep "$NUM"

DATE_TIME="$(date) $(date +%T)"
echo "$DATE_TIME [$RAND_PID] Скрипт завершился, работал $NUM секунд" >> "$FILE_NAME"
