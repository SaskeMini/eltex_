#!/bin/bash

FIFO_NAME=""

for arg in "$@"; do
    if [[ "$arg" =~ ^--pishitesuda=(.*)$ ]]; then
        FIFO_NAME="${BASH_REMATCH[1]}"
    fi
done

[ -p "$FIFO_NAME" ] || mkfifo "$FIFO_NAME"
DATE_TIME="$(date) $(date +%T)"
echo "$DATE_TIME Startup!" >> cuckoo.log

exec 3<"$FIFO_NAME"
exec 4>"$FIFO_NAME"

while true; do
    if read -r line <&3; then
        DATE_TIME="$(date) $(date +%T)"
        if [[ "$line" == "poka" ]]; then
                echo "$DATE_TIME Shutdown!" >> cuckoo.log
                break
        fi
        if [[ "$line" =~ ^[^[]+\[[0-9]+\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
                RAND_NUM=$((RANDOM % 9 + 2))
                echo "$line" | awk -F']' -v randd="$RAND_NUM" '{print $1 "] " randd }' >> cuckoo.log
                # ИСПРАВЛЕНО: пишем в дескриптор 4 и отправляем в фон, чтобы не зависало
                echo "$RAND_NUM" > "$FIFO_NAME"
		sleep 2
        fi
    fi
done

exec 3>&-
exec 4>&-
rm -f "$FIFO_NAME"
