#!/bin/bash
cd /root

while IFS= read -r line; do
	SCRIPT_PID=$(pgrep -f "$line" | grep -v "$$")
	if [ -z "$SCRIPT_PID" ]; then
		nohup "$line" &
		DATE_TIME="$(date) $(date +%T)"
		echo "$DATE_TIME Скрипт перезапущен: $line" >> /root/observer.log 
	fi
done < "/root/observer.conf"
